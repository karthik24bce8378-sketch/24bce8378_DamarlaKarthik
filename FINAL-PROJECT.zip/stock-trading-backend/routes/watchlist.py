from fastapi import APIRouter, HTTPException, Depends
from database import watchlists_collection, stocks_collection
from routes.user import get_current_user
from bson import ObjectId
from datetime import datetime
import logging

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/watchlist", tags=["Watchlist"])

@router.post("/", summary="Create a watchlist")
async def create_watchlist(name: str = "My Watchlist", current_user=Depends(get_current_user)):
    doc = {
        "user_id":    str(current_user["_id"]),
        "name":       name,
        "stocks":     [],
        "created_at": datetime.utcnow().isoformat()
    }
    result = await watchlists_collection.insert_one(doc)
    return {"message": "Watchlist created", "watchlist_id": str(result.inserted_id)}

@router.get("/", summary="Get my watchlist")
async def get_watchlist(current_user=Depends(get_current_user)):
    cursor = watchlists_collection.find({"user_id": str(current_user["_id"])})
    watchlists = []
    async for w in cursor:
        w["_id"] = str(w["_id"])
        watchlists.append(w)
    return {"watchlists": watchlists}

@router.post("/{watchlist_id}/stocks", summary="Add stock to watchlist")
async def add_stock_to_watchlist(watchlist_id: str, stock_id: str, current_user=Depends(get_current_user)):
    stock = await stocks_collection.find_one({"_id": ObjectId(stock_id)})
    if not stock:
        raise HTTPException(status_code=404, detail="Stock not found")
    await watchlists_collection.update_one(
        {"_id": ObjectId(watchlist_id)},
        {"$addToSet": {"stocks": {"stock_id": stock_id, "added_date": datetime.utcnow().isoformat()}}}
    )
    return {"message": f"Stock {stock['ticker_symbol']} added to watchlist"}

@router.delete("/{watchlist_id}/stocks/{stock_id}", summary="Remove stock from watchlist")
async def remove_stock(watchlist_id: str, stock_id: str, current_user=Depends(get_current_user)):
    await watchlists_collection.update_one(
        {"_id": ObjectId(watchlist_id)},
        {"$pull": {"stocks": {"stock_id": stock_id}}}
    )
    return {"message": "Stock removed from watchlist"}

@router.delete("/{watchlist_id}", summary="Delete a watchlist")
async def delete_watchlist(watchlist_id: str, current_user=Depends(get_current_user)):
    await watchlists_collection.delete_one({"_id": ObjectId(watchlist_id)})
    return {"message": "Watchlist deleted"}