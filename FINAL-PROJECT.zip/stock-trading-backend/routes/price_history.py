from fastapi import APIRouter, HTTPException, Depends
from database import price_history_collection, stocks_collection
from routes.user import get_current_user, admin_only
from bson import ObjectId
from datetime import datetime
import logging

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/price-history", tags=["Price History"])

from typing import List
from pydantic import BaseModel

class PriceRecord(BaseModel):
    stock_id: str
    open_price: float
    close_price: float
    high: float
    low: float
    volume: int
    recorded_date: str = None   # optional, defaults to today

# ── BULK INSERT PRICE RECORDS — admin only ───────────────────────────────────
@router.post("/bulk", summary="Insert multiple price records at once — admin only")
async def add_prices_bulk(records: List[PriceRecord], current_user=Depends(admin_only)):
    if not records:
        raise HTTPException(status_code=400, detail="Records list cannot be empty")

    docs = []
    for record in records:
        stock = await stocks_collection.find_one({"_id": ObjectId(record.stock_id)})
        if not stock:
            continue   # skip invalid stock_ids silently
        docs.append({
            "stock_id":      record.stock_id,
            "recorded_date": record.recorded_date or datetime.utcnow().strftime("%Y-%m-%d"),
            "open_price":    record.open_price,
            "close_price":   record.close_price,
            "high":          record.high,
            "low":           record.low,
            "volume":        record.volume
        })

    if not docs:
        raise HTTPException(status_code=400, detail="No valid stock IDs found in records")

    result = await price_history_collection.insert_many(docs)
    logger.info(f"Bulk insert: {len(result.inserted_ids)} price records added")

    return {
        "message":      f"{len(result.inserted_ids)} price records inserted successfully",
        "inserted_ids": [str(id) for id in result.inserted_ids]
    }

# ── BULK DELETE PRICE RECORDS — admin only ───────────────────────────────────
@router.delete("/bulk", summary="Delete multiple price records at once — admin only")
async def delete_prices_bulk(record_ids: List[str], current_user=Depends(admin_only)):
    if not record_ids:
        raise HTTPException(status_code=400, detail="Record ID list cannot be empty")

    object_ids = [ObjectId(rid) for rid in record_ids]

    result = await price_history_collection.delete_many(
        {"_id": {"$in": object_ids}}
    )

    logger.info(f"Bulk delete: {result.deleted_count} price records removed")
    return {
        "message":          f"{result.deleted_count} price records deleted",
        "requested":        len(record_ids),
        "actually_deleted": result.deleted_count
    }

@router.post("/{stock_id}", summary="Insert price record — admin only")
async def add_price(stock_id: str, open_price: float, close_price: float,
                    high: float, low: float, volume: int,
                    current_user=Depends(admin_only)):
    stock = await stocks_collection.find_one({"_id": ObjectId(stock_id)})
    if not stock:
        raise HTTPException(status_code=404, detail="Stock not found")
    doc = {
        "stock_id":      stock_id,
        "recorded_date": datetime.utcnow().strftime("%Y-%m-%d"),
        "open_price":    open_price,
        "close_price":   close_price,
        "high":          high,
        "low":           low,
        "volume":        volume
    }
    await price_history_collection.insert_one(doc)
    return {"message": "Price record added"}

@router.get("/{stock_id}", summary="Get price history for a stock")
async def get_price_history(stock_id: str, current_user=Depends(get_current_user)):
    cursor = price_history_collection.find({"stock_id": stock_id}).sort("recorded_date", -1)
    history = []
    async for record in cursor:
        record["_id"] = str(record["_id"])
        history.append(record)
    if not history:
        raise HTTPException(status_code=404, detail="No price history found for this stock")
    return {"stock_id": stock_id, "history": history}

@router.delete("/{stock_id}/{record_id}", summary="Delete a price record — admin only")
async def delete_price_record(stock_id: str, record_id: str, current_user=Depends(admin_only)):
    await price_history_collection.delete_one({"_id": ObjectId(record_id)})
    return {"message": "Price record deleted"}