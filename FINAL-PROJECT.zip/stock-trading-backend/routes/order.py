from fastapi import APIRouter, HTTPException, Depends
from database import orders_collection, stocks_collection, transactions_collection, accounts_collection
from models.order import OrderCreate, OrderUpdate
from routes.user import get_current_user
from bson import ObjectId
from datetime import datetime
import logging

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/orders", tags=["Orders"])

# ── PLACE ORDER ──────────────────────────────────────────────────────────────
@router.post("/", summary="Place a buy or sell order")
async def place_order(order: OrderCreate, current_user=Depends(get_current_user)):

    # verify stock exists
    stock = await stocks_collection.find_one({"_id": ObjectId(order.stock_id), "is_deleted": False})
    if not stock:
        raise HTTPException(status_code=404, detail="Stock not found")

    # calculate amounts
    total_cost     = order.quantity * order.price_at_order
    brokerage_fee  = total_cost * order.brokerage_rate
    tax            = total_cost * 0.001
    net_amount     = total_cost + brokerage_fee + tax

    # verify account exists
    account = await accounts_collection.find_one({"user_id": str(current_user["_id"])})
    if not account:
        raise HTTPException(
            status_code=400,
            detail="No bank account found. Go to /api/v1/accounts/ and create one first."
        )

    # ── BUY logic ──────────────────────────────────────────────────────────
    if order.order_type.upper() == "BUY":

        # reject if insufficient funds
        if account["balance"] < net_amount:
            raise HTTPException(
                status_code=400,
                detail=f"Insufficient funds. Required: ₹{round(net_amount, 2)}, Available: ₹{round(account['balance'], 2)}"
            )

        # deduct from account balance
        await accounts_collection.update_one(
            {"user_id": str(current_user["_id"])},
            {"$inc": {"balance": -net_amount}}
        )

    # ── SELL logic ─────────────────────────────────────────────────────────
    elif order.order_type.upper() == "SELL":

        # credit account balance on sell
        await accounts_collection.update_one(
            {"user_id": str(current_user["_id"])},
            {"$inc": {"balance": net_amount}}
        )

    else:
        raise HTTPException(status_code=400, detail="order_type must be BUY or SELL")

    # save order
    order_doc = {
        "user_id":        str(current_user["_id"]),
        "stock_id":       order.stock_id,
        "order_type":     order.order_type.upper(),
        "order_category": order.order_category.upper(),
        "quantity":       order.quantity,
        "price_at_order": order.price_at_order,
        "brokerage_rate": order.brokerage_rate,
        "brokerage_fee":  round(brokerage_fee, 2),
        "total_cost":     round(total_cost, 2),
        "net_amount":     round(net_amount, 2),
        "status":         "PENDING",
        "is_deleted":     False,
        "created_at":     datetime.utcnow().isoformat()
    }
    result = await orders_collection.insert_one(order_doc)
    order_id = str(result.inserted_id)

    # auto-create transaction (weak entity)
    transaction_doc = {
        "order_id":        order_id,
        "user_id":         str(current_user["_id"]),
        "stock_id":        order.stock_id,
        "execution_price": order.price_at_order,
        "quantity":        order.quantity,
        "brokerage_fee":   round(brokerage_fee, 2),
        "tax":             round(tax, 2),
        "net_amount":      round(net_amount, 2),
        "timestamp":       datetime.utcnow().isoformat()
    }
    await transactions_collection.insert_one(transaction_doc)

    # mark order as executed
    await orders_collection.update_one(
        {"_id": ObjectId(order_id)},
        {"$set": {"status": "EXECUTED"}}
    )

    # fetch updated balance to show in response
    updated_account = await accounts_collection.find_one({"user_id": str(current_user["_id"])})

    logger.info(f"Order placed: {order_id} | {order.order_type.upper()} | ₹{net_amount}")
    return {
        "message":          "Order placed and executed successfully",
        "order_id":         order_id,
        "order_type":       order.order_type.upper(),
        "total_cost":       round(total_cost, 2),
        "brokerage_fee":    round(brokerage_fee, 2),
        "tax":              round(tax, 2),
        "net_amount":       round(net_amount, 2),
        "remaining_balance": round(updated_account["balance"], 2)
    }

# ── GET ALL ORDERS — admin only ──────────────────────────────────────────────
@router.get("/", summary="Get all orders — admin only")
async def get_all_orders(page: int = 1, limit: int = 10, current_user=Depends(get_current_user)):
    if current_user["role"] != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    skip = (page - 1) * limit
    cursor = orders_collection.find({"is_deleted": False}).skip(skip).limit(limit)
    orders = []
    async for order in cursor:
        order["_id"] = str(order["_id"])
        orders.append(order)
    return {"page": page, "limit": limit, "orders": orders}

# ── GET MY ORDERS ────────────────────────────────────────────────────────────
@router.get("/my-orders", summary="Get all orders of logged in user")
async def get_my_orders(page: int = 1, limit: int = 10, current_user=Depends(get_current_user)):
    skip = (page - 1) * limit
    cursor = orders_collection.find(
        {"user_id": str(current_user["_id"]), "is_deleted": False}
    ).skip(skip).limit(limit)
    orders = []
    async for order in cursor:
        order["_id"] = str(order["_id"])
        orders.append(order)
    return {"page": page, "limit": limit, "orders": orders}

# ── GET ORDER BY ID ──────────────────────────────────────────────────────────
@router.get("/{order_id}", summary="Get a specific order by ID")
async def get_order(order_id: str, current_user=Depends(get_current_user)):
    order = await orders_collection.find_one({"_id": ObjectId(order_id), "is_deleted": False})
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    order["_id"] = str(order["_id"])
    return order

# ── CANCEL ORDER ─────────────────────────────────────────────────────────────
@router.put("/{order_id}/cancel", summary="Cancel a pending order")
async def cancel_order(order_id: str, current_user=Depends(get_current_user)):
    order = await orders_collection.find_one({"_id": ObjectId(order_id)})
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    if order["status"] == "EXECUTED":
        raise HTTPException(status_code=400, detail="Cannot cancel an already executed order")
    if order["user_id"] != str(current_user["_id"]):
        raise HTTPException(status_code=403, detail="You can only cancel your own orders")
    await orders_collection.update_one(
        {"_id": ObjectId(order_id)},
        {"$set": {"status": "CANCELLED"}}
    )
    logger.info(f"Order cancelled: {order_id}")
    return {"message": "Order cancelled successfully"}

# ── DELETE ORDER — admin only ────────────────────────────────────────────────
@router.delete("/{order_id}", summary="Soft delete an order — admin only")
async def delete_order(order_id: str, current_user=Depends(get_current_user)):
    if current_user["role"] != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    result = await orders_collection.update_one(
        {"_id": ObjectId(order_id)},
        {"$set": {"is_deleted": True}}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Order not found")
    return {"message": "Order deleted successfully"}