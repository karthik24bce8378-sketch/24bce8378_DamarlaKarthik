from fastapi import APIRouter, HTTPException, Depends
from database import stocks_collection
from models.stock import StockCreate, StockUpdate
from routes.user import get_current_user, admin_only
from bson import ObjectId
from datetime import datetime
from typing import List
import logging

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/stocks", tags=["Stocks"])

# ── CREATE STOCK — admin only ────────────────────────────────────────────────

@router.post("/", summary="Insert a new stock — admin only")
async def create_stock(stock: StockCreate, current_user=Depends(admin_only)):
    existing = await stocks_collection.find_one({"ticker_symbol": stock.ticker_symbol.upper()})
    if existing:
        raise HTTPException(status_code=400, detail="Stock with this ticker already exists")

    stock_doc = {
        "ticker_symbol": stock.ticker_symbol.upper(),
        "company_name":  stock.company_name,
        "sector":        stock.sector,
        "exchange":      stock.exchange,
        "current_price": stock.current_price,
        "market_cap":    stock.market_cap,
        "is_deleted":    False,
        "created_at":    datetime.utcnow().isoformat()
    }
    result = await stocks_collection.insert_one(stock_doc)

    # create index on ticker_symbol for fast lookups
    await stocks_collection.create_index("ticker_symbol", unique=True)

    logger.info(f"Stock created: {stock.ticker_symbol}")
    return {"message": "Stock created successfully", "id": str(result.inserted_id)}

# ── BULK INSERT STOCKS — admin only ──────────────────────────────────────────
@router.post("/bulk", summary="Insert multiple stocks at once — admin only")
async def create_stocks_bulk(stocks: List[StockCreate], current_user=Depends(admin_only)):
    if not stocks:
        raise HTTPException(status_code=400, detail="Stock list cannot be empty")

    stock_docs = []
    skipped = []

    for stock in stocks:
        existing = await stocks_collection.find_one({"ticker_symbol": stock.ticker_symbol.upper()})
        if existing:
            skipped.append(stock.ticker_symbol.upper())
            continue
        stock_docs.append({
            "ticker_symbol": stock.ticker_symbol.upper(),
            "company_name":  stock.company_name,
            "sector":        stock.sector,
            "exchange":      stock.exchange,
            "current_price": stock.current_price,
            "market_cap":    stock.market_cap,
            "is_deleted":    False,
            "created_at":    datetime.utcnow().isoformat()
        })

    if not stock_docs:
        raise HTTPException(status_code=400, detail=f"All tickers already exist: {skipped}")

    result = await stocks_collection.insert_many(stock_docs)
    logger.info(f"Bulk insert: {len(result.inserted_ids)} stocks added")

    return {
        "message":        f"{len(result.inserted_ids)} stocks inserted successfully",
        "inserted_ids":   [str(id) for id in result.inserted_ids],
        "skipped_tickers": skipped
    }


# ── GET STOCK BY ID ──────────────────────────────────────────────────────────
@router.get("/{stock_id}", summary="Get a stock by ID")
async def get_stock(stock_id: str, current_user=Depends(get_current_user)):
    stock = await stocks_collection.find_one({"_id": ObjectId(stock_id), "is_deleted": False})
    if not stock:
        raise HTTPException(status_code=404, detail="Stock not found")
    stock["_id"] = str(stock["_id"])
    return stock

# ── GET ALL STOCKS — any logged in user ─────────────────────────────────────
@router.get("/", summary="Get all stocks with pagination")
async def get_all_stocks(page: int = 1, limit: int = 10, current_user=Depends(get_current_user)):
    skip = (page - 1) * limit
    cursor = stocks_collection.find({"is_deleted": False}).skip(skip).limit(limit)
    stocks = []
    async for stock in cursor:
        stock["_id"] = str(stock["_id"])
        stocks.append(stock)
    return {"page": page, "limit": limit, "stocks": stocks}

# ── GET STOCK BY TICKER ──────────────────────────────────────────────────────
@router.get("/ticker/{ticker}", summary="Get a stock by ticker symbol")
async def get_stock_by_ticker(ticker: str, current_user=Depends(get_current_user)):
    stock = await stocks_collection.find_one({"ticker_symbol": ticker.upper(), "is_deleted": False})
    if not stock:
        raise HTTPException(status_code=404, detail="Stock not found")
    stock["_id"] = str(stock["_id"])
    return stock

# ── UPDATE STOCK PRICE — admin only ─────────────────────────────────────────
@router.put("/{stock_id}", summary="Update stock price or details — admin only")
async def update_stock(stock_id: str, update: StockUpdate, current_user=Depends(admin_only)):
    update_data = {k: v for k, v in update.model_dump().items() if v is not None}
    if not update_data:
        raise HTTPException(status_code=400, detail="Nothing to update")
    update_data["updated_at"] = datetime.utcnow().isoformat()
    result = await stocks_collection.update_one(
        {"_id": ObjectId(stock_id)},
        {"$set": update_data}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Stock not found")
    logger.info(f"Stock updated: {stock_id}")
    return {"message": "Stock updated successfully"}

# ── BULK DELETE STOCKS — admin only ──────────────────────────────────────────
@router.delete("/bulk", summary="Soft delete multiple stocks at once — admin only")
async def delete_stocks_bulk(stock_ids: List[str], current_user=Depends(admin_only)):
    if not stock_ids:
        raise HTTPException(status_code=400, detail="Stock ID list cannot be empty")

    object_ids = [ObjectId(sid) for sid in stock_ids]

    result = await stocks_collection.update_many(
        {"_id": {"$in": object_ids}},
        {"$set": {"is_deleted": True}}
    )

    logger.info(f"Bulk delete: {result.modified_count} stocks soft-deleted")
    return {
        "message":        f"{result.modified_count} stocks deleted successfully",
        "requested":      len(stock_ids),
        "actually_deleted": result.modified_count
    }


# ── DELETE STOCK — admin only ────────────────────────────────────────────────
@router.delete("/{stock_id}", summary="Soft delete a stock — admin only")
async def delete_stock(stock_id: str, current_user=Depends(admin_only)):
    result = await stocks_collection.update_one(
        {"_id": ObjectId(stock_id)},
        {"$set": {"is_deleted": True}}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Stock not found")
    logger.info(f"Stock deleted: {stock_id}")
    return {"message": "Stock deleted successfully"}
