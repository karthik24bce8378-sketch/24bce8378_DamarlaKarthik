from fastapi import APIRouter, HTTPException
from database import db  

router = APIRouter(prefix="/health", tags=["System Health"])

@router.get("/replica-set")
async def get_replica_set_status():
    try:
        # FIX: Explicitly target the 'admin' database via the client
        status = await db.client.admin.command("replSetGetStatus")
        
        # Format a clean response for Swagger
        members_summary = []
        for member in status.get("members", []):
            members_summary.append({
                "name": member.get("name"),
                "health": "UP" if member.get("health") == 1 else "DOWN",
                "state": member.get("stateStr"),
                "uptime_seconds": member.get("uptime")
            })
            
        return {
            "replica_set_name": status.get("set"),
            "ok": status.get("ok"),
            "cluster_health": members_summary
        }
    except Exception as e:
        raise HTTPException(
            status_code=500, 
            detail=f"Could not fetch replica set status. Error: {str(e)}"
        )