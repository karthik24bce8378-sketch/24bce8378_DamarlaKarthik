from fastapi import APIRouter, HTTPException, Depends
from database import accounts_collection
from routes.user import get_current_user
from pydantic import BaseModel
from typing import Optional
from bson import ObjectId
from datetime import datetime
import logging

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/accounts", tags=["Accounts"])

class AccountCreate(BaseModel):
    bank_name:    str
    ifsc_code:    str
    balance:      float = 0.0           # trading account balance
    bank_balance: float = 100000.0      # simulated bank balance (default 1 lakh)

class AccountUpdate(BaseModel):
    balance: Optional[float] = None
    status: Optional[str] = None

@router.post("/", summary="Create bank account for logged in user")
async def create_account(account: AccountCreate, current_user=Depends(get_current_user)):
    existing = await accounts_collection.find_one({"user_id": str(current_user["_id"])})
    if existing:
        raise HTTPException(status_code=400, detail="Account already exists")
    doc = {
        "user_id":      str(current_user["_id"]),    # 1:1 with user
        "bank_name":    account.bank_name,
        "ifsc_code":    account.ifsc_code,
        "balance":      account.balance,
        "status":       "active",
        "created_date": datetime.utcnow().isoformat()
    }
    result = await accounts_collection.insert_one(doc)
    return {"message": "Account created", "account_id": str(result.inserted_id)}

@router.get("/", summary="Get my account with both balances")
async def get_account(current_user=Depends(get_current_user)):
    account = await accounts_collection.find_one({"user_id": str(current_user["_id"])})
    if not account:
        raise HTTPException(status_code=404, detail="Account not found")
    account["_id"] = str(account["_id"])
    return {
        "account_id":      account["_id"],
        "bank_name":       account["bank_name"],
        "ifsc_code":       account["ifsc_code"],
        "trading_balance": round(account.get("balance", 0), 2),
        "bank_balance":    round(account.get("bank_balance", 0), 2),
        "status":          account["status"],
        "created_date":    account["created_date"]
    }

@router.put("/", summary="Update account balance or status")
async def update_account(update: AccountUpdate, current_user=Depends(get_current_user)):
    update_data = {k: v for k, v in update.model_dump().items() if v is not None}
    if not update_data:
        raise HTTPException(status_code=400, detail="Nothing to update")
    await accounts_collection.update_one(
        {"user_id": str(current_user["_id"])},
        {"$set": update_data}
    )
    return {"message": "Account updated successfully"}

@router.delete("/", summary="Close account")
async def delete_account(current_user=Depends(get_current_user)):
    await accounts_collection.update_one(
        {"user_id": str(current_user["_id"])},
        {"$set": {"status": "closed"}}
    )
    return {"message": "Account closed"}

# ── DEPOSIT — move money from bank balance to trading account ────────────────
@router.post("/deposit", summary="Move money from bank to trading account")
async def deposit_money(amount: float, current_user=Depends(get_current_user)):
    if amount <= 0:
        raise HTTPException(status_code=400, detail="Amount must be greater than 0")

    account = await accounts_collection.find_one({"user_id": str(current_user["_id"])})
    if not account:
        raise HTTPException(status_code=404, detail="Account not found. Create one first.")

    bank_balance = account.get("bank_balance", 0)
    if bank_balance < amount:
        raise HTTPException(
            status_code=400,
            detail=f"Insufficient bank balance. Bank has: ₹{round(bank_balance, 2)}, Requested: ₹{amount}"
        )

    await accounts_collection.update_one(
        {"user_id": str(current_user["_id"])},
        {"$inc": {
            "balance":      amount,       # add to trading account
            "bank_balance": -amount       # deduct from bank
        }}
    )

    updated = await accounts_collection.find_one({"user_id": str(current_user["_id"])})
    logger.info(f"Deposit: ₹{amount} by user {str(current_user['_id'])}")
    return {
        "message":         f"₹{amount} transferred from bank to trading account",
        "deposited":       amount,
        "trading_balance": round(updated["balance"], 2),
        "bank_balance":    round(updated.get("bank_balance", 0), 2)
    }

# ── WITHDRAW MONEY — move funds from trading account back to bank ────────────
@router.post("/withdraw", summary="Withdraw money from trading account to bank")
async def withdraw_money(amount: float, current_user=Depends(get_current_user)):
    if amount <= 0:
        raise HTTPException(status_code=400, detail="Withdrawal amount must be greater than 0")

    account = await accounts_collection.find_one({"user_id": str(current_user["_id"])})
    if not account:
        raise HTTPException(status_code=404, detail="Account not found")

    if account["balance"] < amount:
        raise HTTPException(
            status_code=400,
            detail=f"Insufficient balance. Available: ₹{round(account['balance'], 2)}, Requested: ₹{amount}"
        )

    await accounts_collection.update_one(
        {"user_id": str(current_user["_id"])},
        {"$inc": {
            "balance":      -amount,
            "bank_balance":  amount       # money goes back to bank
        }}
    )

    updated = await accounts_collection.find_one({"user_id": str(current_user["_id"])})
    logger.info(f"Withdrawal: ₹{amount} by user {str(current_user['_id'])}")
    return {
        "message":           f"₹{amount} withdrawn to bank successfully",
        "withdrawn":         amount,
        "trading_balance":   round(updated["balance"], 2),
        "bank_balance":      round(updated.get("bank_balance", 0), 2)
    }