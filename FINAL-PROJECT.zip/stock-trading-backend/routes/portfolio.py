from fastapi import APIRouter, HTTPException, Depends
# Make sure to import orders_collection here!
from database import portfolios_collection, stocks_collection, orders_collection 
from routes.user import get_current_user
from bson import ObjectId
from datetime import datetime
import logging

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/portfolio", tags=["Portfolio & Holdings"])

# ── GET MY PORTFOLIO (Auto-Creates & Calculates from Orders) ─────────────────
@router.get("/", summary="Get user portfolio with live holdings calculated from orders")
async def get_my_portfolio(current_user=Depends(get_current_user)):
    user_id_str = str(current_user["_id"])

    # 1. Check if portfolio exists, if not, automatically create it
    portfolio = await portfolios_collection.find_one({"user_id": user_id_str})
    if not portfolio:
        portfolio_doc = {
            "user_id": user_id_str,
            "created_at": datetime.utcnow().isoformat(),
            "last_updated": datetime.utcnow().isoformat()
        }
        await portfolios_collection.insert_one(portfolio_doc)
        portfolio = await portfolios_collection.find_one({"user_id": user_id_str})
        logger.info(f"Auto-created portfolio for user: {user_id_str}")

    portfolio["_id"] = str(portfolio["_id"])

    # 2. Fetch all EXECUTED orders for this user to calculate active holdings
    cursor = orders_collection.find({
        "user_id": user_id_str,
        "status": "EXECUTED",
        "is_deleted": False
    })

    # Dictionary to aggregate quantities and costs per stock
    stock_aggregates = {}

    async for order in cursor:
        sid = order["stock_id"]
        if sid not in stock_aggregates:
            stock_aggregates[sid] = {"total_buy_qty": 0, "total_buy_cost": 0, "total_sell_qty": 0}

        if order["order_type"] == "BUY":
            stock_aggregates[sid]["total_buy_qty"] += order["quantity"]
            # Calculate total cost based on the price at the time of the order
            stock_aggregates[sid]["total_buy_cost"] += (order["quantity"] * order["price_at_order"])
        elif order["order_type"] == "SELL":
            stock_aggregates[sid]["total_sell_qty"] += order["quantity"]

    holdings = []
    total_invested = 0
    total_current_value = 0

    # 3. Build the live holdings list from the aggregated orders
    for sid, agg in stock_aggregates.items():
        # Calculate how many shares the user actually still owns
        net_qty = agg["total_buy_qty"] - agg["total_sell_qty"]

        # Only include stocks that "aren't sold yet" (net quantity > 0)
        if net_qty > 0:
            stock = await stocks_collection.find_one({"_id": ObjectId(sid)})
            if stock:
                current_price = stock["current_price"]
                
                # Calculate average buy price
                avg_buy_price = agg["total_buy_cost"] / agg["total_buy_qty"] if agg["total_buy_qty"] > 0 else 0

                current_value = net_qty * current_price
                invested_value = net_qty * avg_buy_price
                unrealized_gain = current_value - invested_value

                holdings.append({
                    "stock_id": sid,
                    "stock_ticker": stock["ticker_symbol"],
                    "company_name": stock["company_name"],
                    "quantity_held": net_qty,
                    "avg_buy_price": round(avg_buy_price, 2),
                    "current_price": current_price,
                    "invested_value": round(invested_value, 2),
                    "current_value": round(current_value, 2),
                    "unrealized_gain": round(unrealized_gain, 2)
                })

                total_invested += invested_value
                total_current_value += current_value

    # 4. Attach calculations to the final portfolio response
    portfolio["holdings"] = holdings
    portfolio["total_invested"] = round(total_invested, 2)
    portfolio["total_current_value"] = round(total_current_value, 2)
    portfolio["total_unrealized_gain"] = round(total_current_value - total_invested, 2)
    portfolio["last_updated"] = datetime.utcnow().isoformat()

    return portfolio