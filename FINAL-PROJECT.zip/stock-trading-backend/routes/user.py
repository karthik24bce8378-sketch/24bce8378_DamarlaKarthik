from fastapi import APIRouter, HTTPException, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from database import users_collection
from models.user import UserCreate, UserResponse, UserUpdate
from models.auth import LoginRequest, TokenResponse
from services.auth_service import hash_password, verify_password, create_access_token, decode_token
from bson import ObjectId
from datetime import datetime
import logging

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/users", tags=["Users"])
auth_router = APIRouter(prefix="/api/v1/auth", tags=["Authentication"])
security = HTTPBearer()

# ── helper: get current logged-in user from token ──────────────────────────
async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    token = credentials.credentials
    payload = decode_token(token)
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid or expired token")
    user = await users_collection.find_one({"_id": ObjectId(payload["sub"])})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user

# ── helper: admin only ──────────────────────────────────────────────────────
async def admin_only(current_user=Depends(get_current_user)):
    if current_user["role"] != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    return current_user

# ── REGISTER ────────────────────────────────────────────────────────────────
@auth_router.post("/register", summary="Register a new user")
async def register(user: UserCreate):
    # check if email already exists
    existing = await users_collection.find_one({"email": user.email})
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")

    user_doc = {
        "name":          user.name,
        "email":         user.email,
        "password":      hash_password(user.password),
        "role":          user.role,
        "date_of_birth": user.date_of_birth,
        "kyc_status":    user.kyc_status,
        "is_deleted":    False,
        "created_at":    datetime.utcnow().isoformat()
    }
    result = await users_collection.insert_one(user_doc)
    logger.info(f"New user registered: {user.email}")
    return {"message": "User registered successfully", "id": str(result.inserted_id)}

# ── LOGIN ───────────────────────────────────────────────────────────────────
@auth_router.post("/login", response_model=TokenResponse, summary="Login and get JWT token")
async def login(credentials: LoginRequest):
    user = await users_collection.find_one({"email": credentials.email, "is_deleted": False})
    if not user or not verify_password(credentials.password, user["password"]):
        raise HTTPException(status_code=401, detail="Invalid email or password")

    token = create_access_token({"sub": str(user["_id"]), "role": user["role"]})
    logger.info(f"User logged in: {credentials.email}")
    return {"access_token": token, "token_type": "bearer"}

# ── CREATE USER (admin only) ─────────────────────────────────────────────────
@router.post("/", summary="Create user — admin only")
async def create_user(user: UserCreate, current_user=Depends(admin_only)):
    existing = await users_collection.find_one({"email": user.email})
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")
    user_doc = {
        "name":          user.name,
        "email":         user.email,
        "password":      hash_password(user.password),
        "role":          user.role,
        "kyc_status":    user.kyc_status,
        "is_deleted":    False,
        "created_at":    datetime.utcnow().isoformat()
    }
    result = await users_collection.insert_one(user_doc)
    return {"message": "User created", "id": str(result.inserted_id)}

# ── GET ALL USERS ────────────────────────────────────────────────────────────
@router.get("/", summary="Get all users with pagination")
async def get_all_users(page: int = 1, limit: int = 10, current_user=Depends(get_current_user)):
    skip = (page - 1) * limit
    cursor = users_collection.find({"is_deleted": False}).skip(skip).limit(limit)
    users = []
    async for user in cursor:
        user["_id"] = str(user["_id"])
        user.pop("password", None)      # never return password
        users.append(user)
    return {"page": page, "limit": limit, "users": users}

# ── GET USER BY ID ───────────────────────────────────────────────────────────
@router.get("/{user_id}", summary="Get a user by ID")
async def get_user(user_id: str, current_user=Depends(get_current_user)):
    user = await users_collection.find_one({"_id": ObjectId(user_id), "is_deleted": False})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    user["_id"] = str(user["_id"])
    user.pop("password", None)
    return user

# ── UPDATE USER ──────────────────────────────────────────────────────────────
@router.put("/{user_id}", summary="Update user details")
async def update_user(user_id: str, update: UserUpdate, current_user=Depends(get_current_user)):
    update_data = {k: v for k, v in update.model_dump().items() if v is not None}
    if not update_data:
        raise HTTPException(status_code=400, detail="Nothing to update")
    result = await users_collection.update_one(
        {"_id": ObjectId(user_id)},
        {"$set": update_data}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="User not found")
    logger.info(f"User updated: {user_id}")
    return {"message": "User updated successfully"}

# ── SOFT DELETE ──────────────────────────────────────────────────────────────
@router.delete("/{user_id}", summary="Soft delete a user")
async def delete_user(user_id: str, current_user=Depends(admin_only)):
    result = await users_collection.update_one(
        {"_id": ObjectId(user_id)},
        {"$set": {"is_deleted": True}}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="User not found")
    logger.info(f"User soft-deleted: {user_id}")
    return {"message": "User deleted successfully"}