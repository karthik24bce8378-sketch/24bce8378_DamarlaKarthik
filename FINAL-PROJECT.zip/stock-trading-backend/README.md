# Stock Trading & Portfolio Management System (Backend)

A robust, monolithic REST API built to manage a simulated stock trading platform. This backend handles user wallets, real-time stock pricing, transaction execution, and dynamic portfolio tracking.

Designed with high availability in mind, the system is backed by a locally configured **3-node MongoDB Replica Set**, fulfilling core Database Administration (DBA) architecture requirements.

---
## 🚀 Core Features

* **Secure Authentication:** JWT-based login and registration system.
* **Trading Engine:** Execute Buy/Sell orders with automatic wallet balance deduction.
* **Portfolio Tracking:** Dynamically calculate holdings, total investment, and current portfolio value.
* **Market Management:** Full CRUD operations for stock listings, watchlists, and price histories.
* **High Availability Monitoring:** Includes a dedicated health-check endpoint to monitor the real-time status and failover of the MongoDB cluster.

---
## 🛠 Technology Stack

* **Framework:** Python 3.x + FastAPI
* **Database:** MongoDB Community Edition (Motor Async Driver)
* **Server Environment:** Uvicorn
* **Security:** `passlib` (Bcrypt hashing) + `python-jose` (JWT)

---
### Prerequisites  

You must have:

* Python 3.10+
* MongoDB Server (8.x)

installed locally.

---
## ⚙️ Getting Started (How to Run)

1. Rename .env.example to .env 
2. Now create your secret key and add in place of "your_secret_key_here". 
  
### METHOD 1: One-Click Automated Setup

For a fast, hands-free initialization, run the included setup script. This script automatically builds the necessary data folders, configures the 3-node replica set, initiates the cluster, and boots the FastAPI server.

#### Steps

1. Stop the mongodb server before running this script ([W+R]-> services.msc -> mongoDB -> stop)
2. Open PowerShell or your VS Code Terminal.
3. Execute the script:
  
```powershell

.\start_project_replica.ps1

```

Wait for the success logs. The API will go live automatically.

---
### METHOD 2: Manual DBA Setup (Evaluation Mode)

To configure the database manually or evaluate the DBA architecture step-by-step:

1. Follow the detailed terminal instructions provided in `setup/manual_setup.md` to successfully start and initiate the MongoDB replica set on local ports:
   * 27017
   * 27018
   * 27019

2. Once the database cluster is healthy, open a terminal in the project root folder.

3. Install the required Python dependencies:
```bash

pip install -r requirements.txt

```

4. Start the backend application server:
```bash

uvicorn main:app --reload

```

---
## 🧪 API Testing & Documentation

FastAPI automatically generates interactive, visual documentation.
Once the server is running, navigate your browser to:

👉 **http://localhost:8000/docs**

### Recommended Testing Flow

1. Navigate to `POST /api/v1/auth/register` to create a new investor account.
2. Navigate to `POST /api/v1/auth/login` to retrieve your JWT access token.
3. Click the **Authorize** padlock button at the top right of the Swagger page and paste your token.
4. Check the database health by executing:

```http

GET /api/v1/health/replica-set

```

5. Test the remaining market, portfolio, and transaction endpoints.

---
## 👨‍💻 Author

**Damarla Karthik
24BCE8378**

