from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from routes.user import router as user_router, auth_router
from routes.stock import router as stock_router
from routes.order import router as order_router
from routes.portfolio import router as portfolio_router
from routes.watchlist import router as watchlist_router
from routes.price_history import router as price_history_router
from routes.account import router as account_router
import logging
from routes import health

logging.basicConfig(
    filename="app.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

app = FastAPI(
    title="Stock Trading & Portfolio Management System",
    description="Backend API — MongoDB Project",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_router)
app.include_router(user_router)
app.include_router(stock_router)
app.include_router(order_router)
app.include_router(portfolio_router)
app.include_router(watchlist_router)
app.include_router(price_history_router)
app.include_router(account_router)
app.include_router(health.router, prefix="/api/v1")

@app.get("/", tags=["Root"])
async def root():
    return {
        "message": "Stock Trading & Portfolio Management System API",
        "docs": "http://localhost:8000/docs",
        "status": "running",
        "version": "1.0.0"
    }