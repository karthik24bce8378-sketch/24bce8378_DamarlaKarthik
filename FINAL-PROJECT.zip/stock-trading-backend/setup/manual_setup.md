# MongoDB Replica Set Manual Setup Guide

This guide details the step-by-step process for manually configuring the 3-node MongoDB Replica Set required for the Stock Trading Backend application. 

## Prerequisites
* MongoDB Server (version 8.x) must be installed locally at `C:\Program Files\MongoDB\Server\8.3\bin\`.
* The `mongosh` CLI tool must be installed and accessible in your system PATH.

---

## Step 1: Stop the Default MongoDB Service
By default, Windows runs a single standalone instance of MongoDB in the background. We must stop this service to prevent it from blocking the default port (27017).

1. Press `Windows Key + R` to open the "Run" dialog box.
2. Type `services.msc` and press **Enter**.
3. Scroll down and locate the service named **MongoDB Server**.
4. If the "Status" column says "Running", right-click the service and select **Stop**.

*(Optional: You may want to change the "Startup type" from Automatic to Manual in the Properties menu to prevent conflicts during development).*

---

## Step 2: Create Data Directories
A replica set requires each node to have its own isolated folder to store data. Open a standard Windows terminal (PowerShell or CMD) and run:

```powershell
mkdir C:\data\db0
mkdir C:\data\db1
mkdir C:\data\db2
```

---

## Step 3: Start the Replica Set Nodes
You will need to open **three separate terminal windows**. In each window, you will start a `mongod` instance bound to a different port and data directory. All instances will share the replica set name `myReplSet`.

**Terminal 1 (Primary Node - Port 27017):**
```powershell
"C:\Program Files\MongoDB\Server\8.3\bin\mongod.exe" --replSet myReplSet --dbpath C:\data\db0 --port 27017 --bind_ip localhost
```

**Terminal 2 (Secondary Node - Port 27018):**
```powershell
"C:\Program Files\MongoDB\Server\8.3\bin\mongod.exe" --replSet myReplSet --dbpath C:\data\db1 --port 27018 --bind_ip localhost
```

**Terminal 3 (Secondary Node - Port 27019):**
```powershell
"C:\Program Files\MongoDB\Server\8.3\bin\mongod.exe" --replSet myReplSet --dbpath C:\data\db2 --port 27019 --bind_ip localhost
```

*Note: Once you press Enter, the terminals will fill with logs and appear to "hang". This is normal. Do not close these windows.*

---

## Step 4: Initiate the Replica Set
Currently, the nodes are running independently and do not know about each other. We must initiate the cluster.

1. Open a **fourth** terminal window.
2. Connect to the primary node by running:
   ```powershell
   mongosh --port 27017
   ```
3. Once inside the MongoDB shell (`test>`), paste the following JSON configuration and press Enter:
   ```javascript
   rs.initiate({
      _id: "myReplSet",
      members: [
         { _id: 0, host: "localhost:27017" },
         { _id: 1, host: "localhost:27018" },
         { _id: 2, host: "localhost:27019" }
      ]
   })
   ```

---

## Step 5: Verify Cluster Health
To confirm the replica set is successfully configured, run the following command inside your `mongosh` terminal:

```javascript
rs.status()
```

Scroll through the output and inspect the `members` array. You should verify that:
* Node `27017` is designated as `"PRIMARY"`
* Nodes `27018` and `27019` are designated as `"SECONDARY"`

The replica set is now fully functional and the backend FastAPI server can now be started.