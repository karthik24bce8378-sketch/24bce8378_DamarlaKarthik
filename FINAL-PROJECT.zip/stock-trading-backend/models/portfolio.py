from pydantic import BaseModel
from typing import Optional

class HoldingCreate(BaseModel):
    stock_id: str
    quantity_held: int
    avg_buy_price: float

class HoldingUpdate(BaseModel):
    quantity_held: Optional[int] = None
    avg_buy_price: Optional[float] = None