from pydantic import BaseModel
from typing import Optional

class OrderCreate(BaseModel):
    stock_id: str
    order_type: str          # "BUY" or "SELL"
    order_category: str = "MARKET"   # MARKET, LIMIT, STOP_LOSS
    quantity: int
    price_at_order: float
    brokerage_rate: float = 0.01     # 1% default

class OrderUpdate(BaseModel):
    status: Optional[str] = None     # PENDING, EXECUTED, CANCELLED