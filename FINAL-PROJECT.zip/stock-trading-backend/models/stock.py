from pydantic import BaseModel
from typing import Optional

class StockCreate(BaseModel):
    ticker_symbol: str
    company_name: str
    sector: str
    exchange: str = "NSE"        # NSE or BSE
    current_price: float
    market_cap: Optional[float] = None

class StockUpdate(BaseModel):
    current_price: Optional[float] = None
    market_cap: Optional[float] = None
    sector: Optional[str] = None
    exchange: Optional[str] = None