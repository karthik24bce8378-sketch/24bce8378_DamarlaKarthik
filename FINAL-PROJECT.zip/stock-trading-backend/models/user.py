from pydantic import BaseModel, EmailStr
from typing import Optional
from datetime import datetime

# used when creating a new user (register)
class UserCreate(BaseModel):
    name: str
    email: str
    password: str
    role: str = "investor"          # default role — investor or admin
    date_of_birth: Optional[str] = None
    kyc_status: str = "pending"     # pending / verified

# used when returning user data (never return password)
class UserResponse(BaseModel):
    id: str
    name: str
    email: str
    role: str
    kyc_status: str
    created_at: str

# used when updating a user
class UserUpdate(BaseModel):
    name: Optional[str] = None
    kyc_status: Optional[str] = None
    role: Optional[str] = None