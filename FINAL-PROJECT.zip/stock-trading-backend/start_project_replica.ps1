# ── Stock Trading Backend — One Click Startup ────────────────────────────────
# Just run this file. It handles everything automatically.
# Right-click → Run with PowerShell

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Stock Trading & Portfolio System      " -ForegroundColor Cyan
Write-Host "  MongoDB DBA Assessment                " -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan

$mongod   = "C:\Program Files\MongoDB\Server\8.3\bin\mongod.exe"
$mongosh  = "mongosh"
$dirs     = @("C:\data\db0", "C:\data\db1", "C:\data\db2")
$ports    = @(27017, 27018, 27019)

# ── Step 1: Create data folders ──────────────────────────────────────────────
Write-Host "`n[1/5] Creating data directories..." -ForegroundColor Yellow
foreach ($dir in $dirs) {
    if (-not (Test-Path $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
    }
}
Write-Host "      Done." -ForegroundColor Green

# ── Step 2: Stop default MongoDB service ─────────────────────────────────────
Write-Host "`n[2/5] Stopping default MongoDB service..." -ForegroundColor Yellow
$service = Get-Service -Name "MongoDB" -ErrorAction SilentlyContinue
if ($service -and $service.Status -eq "Running") {
    Stop-Service -Name "MongoDB" -Force
    Start-Sleep -Seconds 2
    Write-Host "      Stopped." -ForegroundColor Green
} else {
    Write-Host "      Already stopped (OK)." -ForegroundColor Gray
}

# ── Step 3: Check if replica nodes already running ───────────────────────────
Write-Host "`n[3/5] Checking replica set nodes..." -ForegroundColor Yellow
$alreadyRunning = $true
foreach ($port in $ports) {
    $conn = Test-NetConnection -ComputerName localhost -Port $port -WarningAction SilentlyContinue
    if (-not $conn.TcpTestSucceeded) {
        $alreadyRunning = $false
    }
}

if ($alreadyRunning) {
    Write-Host "      Replica nodes already running on 27017, 27018, 27019." -ForegroundColor Green
} else {
    Write-Host "      Starting 3 replica nodes..." -ForegroundColor Yellow

    Start-Process -FilePath $mongod `
        -ArgumentList "--replSet myReplSet --dbpath C:\data\db0 --port 27017 --bind_ip localhost" `
        -WindowStyle Minimized
    Write-Host "      Node 0 → port 27017 (Primary)" -ForegroundColor Green
    Start-Sleep -Seconds 1

    Start-Process -FilePath $mongod `
        -ArgumentList "--replSet myReplSet --dbpath C:\data\db1 --port 27018 --bind_ip localhost" `
        -WindowStyle Minimized
    Write-Host "      Node 1 → port 27018 (Secondary)" -ForegroundColor Green
    Start-Sleep -Seconds 1

    Start-Process -FilePath $mongod `
        -ArgumentList "--replSet myReplSet --dbpath C:\data\db2 --port 27019 --bind_ip localhost" `
        -WindowStyle Minimized
    Write-Host "      Node 2 → port 27019 (Secondary)" -ForegroundColor Green

    Write-Host "`n      Waiting for nodes to be ready..." -ForegroundColor Yellow
    Start-Sleep -Seconds 6

    # initiate replica set
    $initiateCmd = 'rs.initiate({ _id: "myReplSet", members: [ { _id: 0, host: "localhost:27017" }, { _id: 1, host: "localhost:27018" }, { _id: 2, host: "localhost:27019" } ] })'
    echo $initiateCmd | & $mongosh --port 27017 --quiet 2>$null
    Start-Sleep -Seconds 4
    Write-Host "      Replica set initiated." -ForegroundColor Green
}

# ── Step 4: Install Python dependencies ──────────────────────────────────────
Write-Host "`n[4/5] Installing Python dependencies..." -ForegroundColor Yellow
$projectPath = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $projectPath
pip install -r requirements.txt --quiet
Write-Host "      Done." -ForegroundColor Green

# ── Step 5: Start FastAPI ─────────────────────────────────────────────────────
Write-Host "[5/5] Starting FastAPI server..." -ForegroundColor Yellow
Write-Host "Everything is ready!" -ForegroundColor Green
Write-Host "Swagger UI : http://localhost:8000/docs" -ForegroundColor White
Write-Host "API Base   : http://localhost:8000/api/v1" -ForegroundColor White

uvicorn main:app --reload