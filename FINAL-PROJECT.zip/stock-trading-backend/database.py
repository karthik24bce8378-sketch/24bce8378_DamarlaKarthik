from motor.motor_asyncio import AsyncIOMotorClient
from dotenv import load_dotenv
import os

load_dotenv()

MONGO_URI = os.getenv("MONGO_URI")
DB_NAME = os.getenv("DB_NAME")

# connect to replica set — all 3 nodes listed for failover
client = AsyncIOMotorClient(
    MONGO_URI,
    replicaSet="myReplSet",
    readPreference="primaryPreferred",   # read from primary, fallback to secondary
    serverSelectionTimeoutMS=5000
)
db = client[DB_NAME]

# collections — one line per entity
users_collection       = db["users"]
accounts_collection    = db["accounts"]
stocks_collection      = db["stocks"]
orders_collection      = db["orders"]
transactions_collection = db["transactions"]
portfolios_collection  = db["portfolios"]
holdings_collection    = db["holdings"]
watchlists_collection  = db["watchlists"]
price_history_collection = db["price_history"]

# ping test!
async def ping_database():
    try:
        # The admin command 'ping' verifies the connection is alive
        await client.admin.command('ping')
        print(f"✅ Successfully connected to MongoDB! Database: {DB_NAME}")
    except Exception as e:
        print(f"❌ Failed to connect to MongoDB. Error: {e}")